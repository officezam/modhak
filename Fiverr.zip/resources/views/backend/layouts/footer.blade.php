
<!-- footer content -->
<footer>
    <div class="pull-right">
        Admin Template by <a href="#">Amir Shahzad</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
